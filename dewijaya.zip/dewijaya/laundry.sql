-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 13, 2023 at 09:29 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `pakaian`
--

CREATE TABLE `pakaian` (
  `id_pakaian` int(11) NOT NULL,
  `nama_pakaian` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pakaian`
--

INSERT INTO `pakaian` (`id_pakaian`, `nama_pakaian`) VALUES
(1, 'Kaos'),
(2, 'Celana Panjang'),
(3, 'Celana Pendek'),
(4, 'kemeja Panjang'),
(5, 'kemeja Pendek');

-- --------------------------------------------------------

--
-- Table structure for table `tarif`
--

CREATE TABLE `tarif` (
  `id_tarif` int(11) NOT NULL,
  `nama_tarif` varchar(100) NOT NULL,
  `waktu_tarif` varchar(128) NOT NULL,
  `biaya_tarif` double NOT NULL,
  `jenis_tarif` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tarif`
--

INSERT INTO `tarif` (`id_tarif`, `nama_tarif`, `waktu_tarif`, `biaya_tarif`, `jenis_tarif`) VALUES
(9, 'Kiloan 1', '2 hari', 6000, 'Kg'),
(10, 'Kiloan 2', '1 hari', 10000, 'Kg'),
(11, 'Kiloan 3', '8 Jam', 15000, 'Kg'),
(12, 'Bad Cover', '2 Hari', 25000, 'Satuan'),
(13, 'Sprei', '2 Hari', 15000, 'Satuan'),
(14, 'Selimut', '2 Hari', 10000, 'Satuan'),
(15, 'Tas', '3 Hari', 15000, 'Satuan'),
(16, 'Sepatu', '2 Hari', 10000, 'Satuan'),
(17, 'Ransel', '3 Hari', 10000, 'Satuan'),
(18, 'Jasa Cuci', '1 Hari', 4000, 'Kg'),
(19, 'Jasa Setrika', '1 Hari', 4000, 'Kg'),
(20, 'Boneka Kecil', '2 Hari', 5000, 'Satuan'),
(21, 'Boneka Sedang', '3 Hari', 10000, 'Satuan'),
(22, 'Boneka Besar', '3 Hari', 20000, 'Satuan'),
(23, 'Boneka Jumbo', '3 Hari', 30000, 'Satuan'),
(24, 'Karpet', '3 Hari', 10000, 'Kg');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `tgl_transaksi` varchar(12) NOT NULL,
  `jam_transaksi` varchar(12) NOT NULL,
  `paket_transaksi` varchar(128) NOT NULL,
  `jenis_paket` varchar(30) NOT NULL,
  `berat_jumlah` double NOT NULL,
  `total_transaksi` double NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `nama`, `tgl_transaksi`, `jam_transaksi`, `paket_transaksi`, `jenis_paket`, `berat_jumlah`, `total_transaksi`, `status`) VALUES
('13032314234001', 'Dewi', '13-03-2023', '14-23-40', 'Kiloan 1 (6000)', 'Kg', 2, 12000, 0),
('13032314243802', 'Dewi', '13-03-2023', '14-24-38', 'Kiloan 1 (6000)', 'Kg', 2, 12000, 0),
('13032314253503', 'Dewi', '13-03-2023', '14-25-35', 'Kiloan 1 (6000)', 'Kg', 2, 12000, 0),
('13032314262104', 'DOY', '13-03-2023', '14-26-21', 'Boneka Jumbo (30000)', 'Pcs', 1, 30000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_detail`
--

CREATE TABLE `transaksi_detail` (
  `id_detail` int(11) DEFAULT NULL,
  `id_transaksi_d` varchar(128) NOT NULL,
  `nama_d` varchar(128) NOT NULL,
  `jumlah_d` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi_detail`
--

INSERT INTO `transaksi_detail` (`id_detail`, `id_transaksi_d`, `nama_d`, `jumlah_d`) VALUES
(NULL, '13032314243802', 'Celana Panjang', 1),
(NULL, '13032314243802', 'kemeja Panjang', 1),
(NULL, '13032314262104', 'Boneka Jumbo', 1);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_status`
--

CREATE TABLE `transaksi_status` (
  `id_status` int(11) DEFAULT NULL,
  `id_transaksi_s` varchar(128) DEFAULT NULL,
  `cuci` int(1) NOT NULL,
  `kering` int(1) NOT NULL,
  `strika` int(1) NOT NULL,
  `siap` int(1) NOT NULL,
  `selesai` int(1) NOT NULL,
  `tgl_ambil` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi_status`
--

INSERT INTO `transaksi_status` (`id_status`, `id_transaksi_s`, `cuci`, `kering`, `strika`, `siap`, `selesai`, `tgl_ambil`) VALUES
(NULL, '13032314253503', 1, 0, 0, 0, 0, '0'),
(NULL, '13032314262104', 1, 0, 0, 0, 0, '0'),
(NULL, NULL, 1, 0, 0, 0, 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) DEFAULT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `level` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `level`) VALUES
(NULL, 'Dewi', 'Dewi', '$2y$10$arZjGoNwD7to3Q9cU3MTKOZpuwnvk8X8YM2dmEAFlTPyIMIl8qiNS', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
