-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2020 at 12:46 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbp_laundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `pakaian`
--

CREATE TABLE `pakaian` (
  `id_pakaian` int(11) NOT NULL,
  `nama_pakaian` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pakaian`
--

INSERT INTO `pakaian` (`id_pakaian`, `nama_pakaian`) VALUES
(1, 'Kaos'),
(2, 'Celana Panjang'),
(3, 'Celana Pendek'),
(4, 'kemeja Panjang'),
(5, 'kemeja Pendek');

-- --------------------------------------------------------

--
-- Table structure for table `tarif`
--

CREATE TABLE `tarif` (
  `id_tarif` int(11) NOT NULL,
  `nama_tarif` varchar(100) NOT NULL,
  `waktu_tarif` varchar(128) NOT NULL,
  `biaya_tarif` double NOT NULL,
  `jenis_tarif` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tarif`
--

INSERT INTO `tarif` (`id_tarif`, `nama_tarif`, `waktu_tarif`, `biaya_tarif`, `jenis_tarif`) VALUES
(9, 'Kiloan 1', '2 hari', 6000, 'Kg'),
(10, 'Kiloan 2', '1 hari', 10000, 'Kg'),
(11, 'Kiloan 3', '8 Jam', 15000, 'Kg'),
(12, 'Bad Cover', '2 Hari', 25000, 'Satuan'),
(13, 'Sprei', '2 Hari', 15000, 'Satuan'),
(14, 'Selimut', '2 Hari', 10000, 'Satuan'),
(15, 'Tas', '3 Hari', 15000, 'Satuan'),
(16, 'Sepatu', '2 Hari', 10000, 'Satuan'),
(17, 'Ransel', '3 Hari', 10000, 'Satuan'),
(18, 'Jasa Cuci', '1 Hari', 4000, 'Kg'),
(19, 'Jasa Setrika', '1 Hari', 4000, 'Kg'),
(20, 'Boneka Kecil', '2 Hari', 5000, 'Satuan'),
(21, 'Boneka Sedang', '3 Hari', 10000, 'Satuan'),
(22, 'Boneka Besar', '3 Hari', 20000, 'Satuan'),
(23, 'Boneka Jumbo', '3 Hari', 30000, 'Satuan'),
(24, 'Karpet', '3 Hari', 10000, 'Kg');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `tgl_transaksi` varchar(12) NOT NULL,
  `jam_transaksi` varchar(12) NOT NULL,
  `paket_transaksi` varchar(128) NOT NULL,
  `jenis_paket` varchar(30) NOT NULL,
  `berat_jumlah` double NOT NULL,
  `total_transaksi` double NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `nama`, `tgl_transaksi`, `jam_transaksi`, `paket_transaksi`, `jenis_paket`, `berat_jumlah`, `total_transaksi`, `status`) VALUES
('08041912172601', 'Dany Adhi Prabowo', '08-04-2019', '12-17-26', 'Kiloan 1 (6000)', 'Kg', 2, 12000, 0),
('08041912181802', 'Andy Wijaya', '08-04-2019', '12-18-18', 'Boneka Besar (20000)', 'Pcs', 1, 20000, 1),
('08041912181803', 'Prabowo', '08-04-2019', '12-18-18', 'Selimut (10000)', 'Pcs', 2, 20000, 0),
('19041919493304', 'Dany Adhi Prabowo', '19-04-2019', '19-49-33', 'Kiloan 2 (10000)', 'Kg', 1, 10000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_detail`
--

CREATE TABLE `transaksi_detail` (
  `id_detail` int(11) NOT NULL,
  `id_transaksi_d` varchar(128) NOT NULL,
  `nama_d` varchar(128) NOT NULL,
  `jumlah_d` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi_detail`
--

INSERT INTO `transaksi_detail` (`id_detail`, `id_transaksi_d`, `nama_d`, `jumlah_d`) VALUES
(27, '08041912172601', 'Celana Panjang', 2),
(28, '08041912172601', 'Celana Pendek', 3),
(29, '08041912172601', 'Kaos', 2),
(30, '08041912181802', 'Boneka Besar', 1),
(31, '08041912181803', 'Selimut', 2),
(32, '15041911453804', 'Kaos', 3),
(33, '15041911453804', 'Celana Pendek', 2),
(34, '15041911453804', 'kemeja Pendek', 2),
(35, '15041911453804', 'Celana Panjang', 1),
(36, '19041919493304', 'Celana Panjang', 2);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_status`
--

CREATE TABLE `transaksi_status` (
  `id_status` int(11) NOT NULL,
  `id_transaksi_s` varchar(128) NOT NULL,
  `cuci` int(1) NOT NULL,
  `kering` int(1) NOT NULL,
  `strika` int(1) NOT NULL,
  `siap` int(1) NOT NULL,
  `selesai` int(1) NOT NULL,
  `tgl_ambil` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi_status`
--

INSERT INTO `transaksi_status` (`id_status`, `id_transaksi_s`, `cuci`, `kering`, `strika`, `siap`, `selesai`, `tgl_ambil`) VALUES
(1, '08041912172601', 1, 1, 1, 0, 0, '2019-04-15 11:24:47'),
(2, '08041912181802', 1, 1, 1, 1, 1, '19-02-2020 10-16-47'),
(3, '08041912181803', 1, 1, 1, 0, 0, '2019-04-15 11:24:47'),
(5, '19041919493304', 1, 1, 1, 1, 0, '19-04-2019 23-10-23');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `level` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `level`) VALUES
(1, 'Dany Adhi Prabowo', 'dany4', '$2y$10$NuJpueDsXtO2jre2Dq5TXucFV8hEnOV4CLUnMAgvCpO5o2wIe6wOG', 1),
(2, 'Dany adhi prabowo', 'admin', '$2y$10$pnZ4M1.cBK0qdEp.Z/eOO.xsQTEAqlAMUIk125r9BMq9OlS2yfo/q', 1),
(3, 'dany', 'dany', '$2y$10$NuJpueDsXtO2jre2Dq5TXucFV8hEnOV4CLUnMAgvCpO5o2wIe6wOG', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pakaian`
--
ALTER TABLE `pakaian`
  ADD PRIMARY KEY (`id_pakaian`);

--
-- Indexes for table `tarif`
--
ALTER TABLE `tarif`
  ADD PRIMARY KEY (`id_tarif`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD PRIMARY KEY (`id_detail`);

--
-- Indexes for table `transaksi_status`
--
ALTER TABLE `transaksi_status`
  ADD PRIMARY KEY (`id_status`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pakaian`
--
ALTER TABLE `pakaian`
  MODIFY `id_pakaian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tarif`
--
ALTER TABLE `tarif`
  MODIFY `id_tarif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `transaksi_status`
--
ALTER TABLE `transaksi_status`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
