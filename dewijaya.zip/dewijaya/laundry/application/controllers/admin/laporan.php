<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

	var $folder 	= 'laporan/';
	var $section 	= 'Transaksi';
	var $table		= 'transaksi';


	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            redirect(base_url('')); 
        };
		$this->load->model(['model']);
	}


	public function index()
	{
		$data = [
					'content'	=> $this->folder.'coba',
					'section'	=> $this->section,
					'tampil'	=> $this->model->get_all($this->table)->result()
				];
		$this->load->view('template/template', $data);
	}
	public function downloadlaporan()
    {
        $this->load->library('pdfgenerator');

        $tanggalawal = $this->input->get('tanggalawal');
        $tanggalakhir = $this->input->get('tanggalakhir');

        $data['title_pdf'] = 'Laporan Penjualan Toko Electro';
        $data['laporantransaksi'] = $this->transaksimodel->getlaporan($this->input->get('tanggalawal'), $this->input->get('tanggalakhir'));

        $data['total'] = $this->db
            ->query("Select SUM(total) as totalpendapatan from transaksi Where tanggal_transaksi BETWEEN '$tanggalawal 00:00:00' AND '$tanggalakhir 00:00:00'")
            ->row()->totalpendapatan;

        $file_pdf = 'laporan_ablaundry';
        $paper = 'A4';
        $orientation = "portrait";

        $html = $this->load->view('owner/laporan_pdf', $data, true);

        $this->pdfgenerator->generate($html, $file_pdf, $paper, $orientation);
    }

}

/* End of file laporan.php */
/* Location: ./application/controllers/admin/laporan.php */