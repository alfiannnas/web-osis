<?php 
include('header.php');


if(!defined('BASEPATH')) exit ('No direct script access allowed');
if($content){$this->load->view($content);};


include('footer.php');
?>